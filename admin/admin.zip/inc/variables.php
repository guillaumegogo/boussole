<?php
$titredusite="la boussole des jeunes";
$message_erreur_bd="L'application a rencontré un problème. Ta demande n'a pas pu être enregistrée. Merci de contacter l'administrateur du site si le problème persiste.";
$url_admin="http://www.gogo.fr/boussole/admin";
?>