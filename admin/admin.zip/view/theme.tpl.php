<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link rel="stylesheet" href="css/style_backoffice.css" />
	<link rel="icon" type="image/png" href="img/compass-icon.png" />	
	<script type="text/javascript" language="javascript" src="js/jquery-1.12.0.js"></script>
	<script type="text/javascript" language="javascript" src="js/jquery.filterByText.js"></script>
	<script type="text/javascript" language="javascript" src="js/selectbox.js"></script>
	<title>Boussole des jeunes</title>
</head>

<body>
<h1 class="bandeau"><a href="accueil.php">Administration de la boussole des jeunes</a></h1>
<div class="statut"><?php echo $_SESSION['accroche']; ?> (<a href="index.php">déconnexion</a>)</div> 

<div class="container">

<?php if($select_theme) { ?>
<form method="post" class="liste_territoire">
	<label for="choix_theme">Thème :</label>
	<select name="choix_theme" onchange="this.form.submit()" ><option value="">A choisir</option><?php echo $select_theme; ?></select>
</form>
<?php } ?>

<h2>Gestion des thèmes</h2>
<div class="soustitre"><?php echo $msg; ?></div>

<?php
if ($id_theme_choisi) {
?>
<form method="post"  class="detail">
	<fieldset style="margin-bottom:1em;">
	<legend>Gérer le theme</legend>
		<div class="deux_colonnes" style="width:auto; min-width:auto;">
			<div class="lab">
				<label for="libelle_theme" class="court">Libellé :</label>
				<input type="text" name="libelle_theme" value="<?php echo $libelle_theme_choisi; ?>">
			</div>
			<div class="lab">
				<label for="actif" class="court">Actif :</label>
				<input type="radio" name="actif" value="1" <?php if ($actif_theme_choisi=="1") { echo "checked"; } ?>> Oui 
				<input type="radio" name="actif" value="0" <?php if ($actif_theme_choisi=="0") { echo "checked"; } ?>> Non
				
			</div>
			<input type="hidden" name="maj_id_theme" value="<?php echo $id_theme_choisi; ?>">
		</div>
		<input type="submit" style="display:inline-block; vertical-align:bottom;" name="submit_theme" value="Valider">
	</fieldset>
	
	<fieldset style="margin-bottom:1em;">
	<legend>Liste des sous-thèmes</legend>
<?php 
	if (mysqli_num_rows($result_st) > 0) {
?>
		<table><thead><tr><th>Libellé</th><th>Ordre d'affichage</th><th>Actif</th></tr></thead><tbody>
<?php 
		while($row = mysqli_fetch_assoc($result_st)) {
			if ($row['id_theme']!=$id_theme_choisi) {
?>
			<tr><td>
				<input type="hidden" name="sthemes[<?= $i ?>][]" value="<?= $row['id_theme'] ?>" />
				<input type="text" name="sthemes[<?= $i ?>][]" value="<?= $row['libelle_theme'] ?>" style="width:60em;"/>
			</td>
			<td>
				<input type="text" name="sthemes[<?= $i ?>][]" value="<?= $row['ordre_theme'] ?>" style="width:3em"/>
			</td>
			<td>
				<input type="radio" name="sthemes[<?= $i ?>][]" value="1" <?= ($row['actif_theme']==="1") ? "checked" : "" ?>> Oui 
				<input type="radio" name="sthemes[<?= $i ?>][]" value="0" <?= ($row['actif_theme']==="0") ? "checked" : "" ?>> Non
			</td></tr>
<?php
				$i++;
			}
		}
?>
		</tbody></table>
		<input type="submit" style="display:block; margin:0 auto;" name="submit_meta" value="Valider">
<?php
	} else {
?>
	<div class="soustitre">Aucun sous-thème</div>
<?php
	}
?>
	</fieldset>
	
	<fieldset>
	<legend>Ajouter un sous-thème</legend>
		<div class="deux_colonnes" style="width:auto; min-width:auto;">
			<div class="lab">
				<label for="libelle_nouveau_sous_theme" class="court">Libellé :</label>
				<input type="text" name="libelle_nouveau_sous_theme" value="">
			</div>
		</div>
		<input type="submit" style="display:inline-block; vertical-align:bottom;" name="submit_nouveau_sous_theme" value="Valider">
	</fieldset>
	
</form>

<?php } ?>
</div>
 
<?php 
if ($ENVIRONNEMENT=="LOCAL") {
	echo "<pre>"; print_r(@$_POST); echo @$sql." ".@$sql2; echo "</pre>"; 
}
?>
</body>
</html>